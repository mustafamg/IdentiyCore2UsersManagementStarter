﻿namespace IdentityUserRoleExample.Models
{
    public class ModalHeader
    {
        public string Heading { get; set; }
    }
}