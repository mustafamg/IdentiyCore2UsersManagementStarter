﻿namespace IdentityUserRoleExample.Code
{
    public enum ModalSize
    {
        Small,
        Large,
        Medium
    }
}
